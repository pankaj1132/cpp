#include<iostream>
using namespace std;
int main() {
	
	int a[1000000];
	
	int n;
	cin>>n;
    for(int i=n;i>=0;i--){
        cout<<a[i]<<" ";
    }cout<<endl;
	return 0;
}