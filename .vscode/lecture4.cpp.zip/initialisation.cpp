#include <iostream>
using namespace std;
int main(){
    int a=5;//initialisation
    int b=7;
    int c=10;
    c=8;//assignment
    cout<<"a:"<<a;
    cout<<"b:"<<b;
    cout<<"c:"<<c;

    return 0;
}