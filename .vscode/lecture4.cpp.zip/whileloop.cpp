#include <iostream>
using namespace std;
int main(){
    int i; int n;
    cin>>n;
    i=1;
    while(i<=n){
        cout<<i<<""<<endl;
        i++;
    }
    return 0;
}