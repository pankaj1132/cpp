#include <iostream>
using namespace std;
int main(){
    int a;
    cin>>a;
    if(a<100&&a>9){
        cout<<"hello" <<endl;


    }
    else if (a<200&&a>101){
        cout<<"world"<<endl;
    }
    else{
        cout<<"welcome to coding"<<endl;
    }
    return 0;
}