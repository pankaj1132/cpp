#include <iostream>
#include <climits>
using namespace std;
int main(){
    cout<<"hell world";
    return 0;
}